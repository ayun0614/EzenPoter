import "./css/Sidebar.css"
import AsideHeader from "./img/aside_header.png";
import AsideUpper from "./img/aside_upper.png";
import AsideImg1 from './img/aside_img1.png';
import AsideImg2 from './img/aside_img2.png';
import AsideImg3 from './img/aside_img3.png';

const Sidebar = () => {
    return (
        <aside>
            <section>
                <div className="test">
                </div>
                <div className="sticky">
                    <img src={AsideHeader} className="asideHeader" alt="imgHeader" />
                    <div className="menu">
                        <img src={AsideImg1} className="asideImg" alt="img1" />
                        <hr className="asideHr" />
                        <img src={AsideImg2} className="asideImg" alt="img2" />
                        <hr className="asideHr" />
                        <img src={AsideImg3} className="asideImg" alt="img3" />
                    </div>
                    <div className="upper">
                        <img src={AsideUpper} className="asideUpper" alt="upper" />
                    </div>
                </div>
            </section>
        </aside>
    );
};

export default Sidebar;
